@echo off
setlocal
cd /d "%~dp0"

echo ===== ��ǰ��ĿĿ¼ =====
cd

echo.
echo ===== ��� Android SDK ·�� =====
if exist android\local.properties (
  type android\local.properties | findstr /i "sdk.dir flutter.sdk"
)

set SDK_PATH=
if defined ANDROID_HOME set SDK_PATH=%ANDROID_HOME%
if not defined SDK_PATH if defined ANDROID_SDK_ROOT set SDK_PATH=%ANDROID_SDK_ROOT%
if not defined SDK_PATH if exist D:\AndroidSDK set SDK_PATH=D:\AndroidSDK

echo.
echo �Ʋ� SDK_PATH=%SDK_PATH%

echo.
echo ===== �Ѱ�װ Build-Tools �汾 =====
if defined SDK_PATH (
  if exist "%SDK_PATH%\build-tools" (
    dir /b "%SDK_PATH%\build-tools"
  ) else (
    echo δ�ҵ� "%SDK_PATH%\build-tools"
  )
) else (
  echo δ�ܴӻ��������� D:\AndroidSDK �Ʋ� SDK ·����
)

echo.
echo ===== ��ʼ���� APK =====
flutter clean
flutter pub get
flutter build apk

pause
