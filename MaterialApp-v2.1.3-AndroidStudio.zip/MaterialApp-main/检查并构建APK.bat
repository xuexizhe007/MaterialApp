@echo off
setlocal
cd /d "%~dp0"

echo ===== ��ǰĿ¼ =====
cd

echo.
echo ===== �Ѱ�װ Android Build-Tools =====
if exist "%ANDROID_HOME%\build-tools" (
  dir /b "%ANDROID_HOME%\build-tools"
) else if exist "%ANDROID_SDK_ROOT%\build-tools" (
  dir /b "%ANDROID_SDK_ROOT%\build-tools"
) else if exist "D:\AndroidSDK\build-tools" (
  dir /b "D:\AndroidSDK\build-tools"
) else (
  echo δ��⵽ build-tools Ŀ¼������ Android Studio �� SDK Manager �а�װ Android SDK Build-Tools��
)

echo.
echo ===== ��ʼ���� APK =====
flutter clean
flutter pub get
flutter build apk

pause
